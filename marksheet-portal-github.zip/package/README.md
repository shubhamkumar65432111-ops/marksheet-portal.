# Marksheet Portal

Publish-ready copy of the supplied standalone Result & Marksheet Portal.

## GitHub Pages
1. Rename/keep `index.html` at the repository root.
2. Create a GitHub repository and upload `index.html`.
3. Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.

## Important
This supplied application uses Dexie/IndexedDB in the browser. Records added through its admin/database features are local to that browser/device; GitHub Pages does not provide a shared server database. For a multi-user public portal with one shared student database, a backend/database must be added separately.

## Included
- Registration-number search UI
- Result display
- Marksheet PDF generation
- QR code generation
- Existing client-side database/admin logic from the supplied file
